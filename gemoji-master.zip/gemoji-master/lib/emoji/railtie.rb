warn "requiring 'emoji/railtie' is deprecated. " +
  "Please manually add Emoji.images_path to your config.assets.paths."

# Automatic path configuration via a railtie is intentionally removed.
# Please see the README for details. Any patches to readded it by a
# non-repo collab will be closed without comment.
